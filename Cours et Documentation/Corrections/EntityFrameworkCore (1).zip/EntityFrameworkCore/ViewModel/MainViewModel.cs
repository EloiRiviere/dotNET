﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkCore.ViewModel
{
    public class MainViewModel : BaseNotifyPropertyChanged
    {

        public List<Model.Author> AuthorsList
        {
            get
            {
                return DataAccess.BooksDbContext.Current.Authors.ToList();
            }
        }

        public Model.Author SelectedAuthor
        {
            get { return GetValue<Model.Author>(); }
            set { SetValue(value); }
        }


        public async Task LoadData()
        {

            var context =  DataAccess.BooksDbContext.Current;

            // Ajout en cache
            context.Add(new Model.Author()
            {
                LastName = "Monroe",
                FirstName = "John",
                Phone = "555 555 555"
            });

            // Enregistrement
            await context.SaveChangesAsync();

            // Sélection
            context.Books.Where(b => b.PubDate > DateTime.Now.AddYears(-5))
                         .OrderBy(b => b.Price)
                         .Include(b => b.Authors)
                         .Select(b => b.Authors)
                         .ToList();


        }

        public async Task AddAuthor()
        {
            var context = DataAccess.BooksDbContext.Current;

            context.Add(new Model.Author()
            {
                LastName = "Monroe",
                FirstName = "John",
                Phone = "555 555 555"
            });

            // Enregistrement
            await context.SaveChangesAsync();

            OnPropertyChanged(nameof(AuthorsList));
        }

    }
}
