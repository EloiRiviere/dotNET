﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using static System.Environment;

namespace EntityFrameworkCore.DataAccess
{
    public class BooksDbContext : DbContext
    {

        private static BooksDbContext _context = null;
        public static async Task<BooksDbContext> GetCurrent()
        {
            if (_context == null)
            {
                _context = new BooksDbContext(
                    Path.Combine(GetFolderPath(SpecialFolder.LocalApplicationData), "database.db"));
                await _context.Database.MigrateAsync();
            }
            return _context;
        }

        internal BooksDbContext(DbContextOptions options) : base(options) { }
        private BooksDbContext(string databasePath) : base()
        {
            DatabasePath = databasePath;
        }

        public string DatabasePath { get; }

        public DbSet<Model.Author> Authors { get; set; }
        public DbSet<Model.Book> Books { get; set; }
        public DbSet<Model.AuthorBook> AuthorsBooks { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.EnableSensitiveDataLogging();
            optionsBuilder.UseSqlite($"Filename={DatabasePath}");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Model.AuthorBook>()
                                .HasKey(ab => new { ab.AuthorId, ab.BookId });

            //modelBuilder.Entity<Model.AuthorBook>().HasOne(ab => ab.Book)
            //                                       .WithMany(b => b.Authors)
            //                                       .HasForeignKey(ab => ab.BookId);
        }

    }
}
