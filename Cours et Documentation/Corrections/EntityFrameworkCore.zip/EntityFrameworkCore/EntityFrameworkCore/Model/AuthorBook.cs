﻿using System.ComponentModel.DataAnnotations.Schema;

namespace EntityFrameworkCore.Model
{
    public class AuthorBook
    {

        public int AuthorId { get; set; }
        public int BookId { get; set; }

        public int Order { get; set; }

        [ForeignKey(nameof(AuthorId))]
        public Author Author { get; set; }

        [ForeignKey(nameof(BookId))]
        public Book Book { get; set; }

    }
}
