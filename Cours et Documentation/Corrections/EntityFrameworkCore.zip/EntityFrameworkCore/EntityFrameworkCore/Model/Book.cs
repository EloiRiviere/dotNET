﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EntityFrameworkCore.Model
{
    public class Book
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public string  Title { get; set; }

        public decimal Price { get; set; }

        public DateTime PubDate { get; set; }

        [InverseProperty(nameof(AuthorBook.Book))]
        public List<AuthorBook> Authors { get; set; }
    }
}
