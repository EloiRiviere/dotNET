﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkCore.ViewModel
{
    public class MainViewModel
    {

        public async Task LoadData()
        {

            var context = await DataAccess.BooksDbContext.GetCurrent();

            // Ajout en cache
            context.Add(new Model.Author()
            {
                LastName = "Monroe",
                FirstName = "John",
                Phone = "555 555 555"
            });

            // Enregistrement
            await context.SaveChangesAsync();

            // Sélection
            context.Books.Where(b => b.PubDate > DateTime.Now.AddYears(-5))
                         .OrderBy(b => b.Price)
                         .Include(b => b.Authors)
                         .Select(b => b.Authors)
                         .ToList();


        }

    }
}
