﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordsManager.Utils
{
    public static class Crypto
    {

        public static string Encrypt(string clear)
        {
            return "";
        }

        public static string Decrypt(string encrypted)
        {
            return "";
        }

    }
}
