﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Template_ListBox
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Personne> _personnes;
        public ObservableCollection<Personne> Personnes
        {
            get
            {
                if (_personnes == null) _personnes = new ObservableCollection<Personne>();
                return _personnes;
            }
        }

        public MainWindow()
        {
            this.DataContext = this;
            this.Personnes.Add(new Personne() { Nom = "DURAND", Prenom = "Paul", Adresse = "31 rue Smith", CodePostal = "69002", Ville = "LYON" });
            this.Personnes.Add(new Personne() { Nom = "CORDIER", Prenom = "Cyril", Adresse = "5 rue Bel Air", CodePostal = "69360", Ville = "SEREZIN DU RHÔNE" });
            InitializeComponent();
        }
    }
}
