﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        private Dictionary<string, object> _propertyValues = new Dictionary<string, object>();

        public T GetValue<T>([CallerMemberName] string propertyName = null)
        {
            if (_propertyValues.ContainsKey(propertyName))
                return (T)_propertyValues[propertyName];
            return default(T);
        }
        public bool SetValue<T>(T newValue, [CallerMemberName] string propertyName = null)
        {
            var currentValue = GetValue<T>(propertyName);
            if (currentValue == null && newValue != null
             || currentValue != null && !currentValue.Equals(newValue))
            {
                _propertyValues[propertyName] = newValue;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
                return true;
            }
            return false;
        }

        #endregion

        
        public string MonTexte
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> MaListe
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public string TexteSelectionne
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ObjetComplexe> MaListeComplexe
        {
            get { return GetValue<ObservableCollection<ObjetComplexe>>(); }
            set { SetValue(value); }
        }
        public ObjetComplexe ObjetSelectionne
        {
            get { return GetValue<ObjetComplexe>(); }
            set { SetValue(value); }
        }

        public MainWindow()
        {
            this.DataContext = this;

            InitializeComponent();

            MonTexte = "Un texte issu du databinding.";

            TexteSelectionne = "";
            MaListe = new ObservableCollection<string>();
            MaListe.Add("Elément n°1");
            MaListe.Add("Elément n°2");
            MaListe.Add("Elément n°3");

            ObjetSelectionne = null;
            MaListeComplexe = new ObservableCollection<ObjetComplexe>();
            MaListeComplexe.Add(new ObjetComplexe("Titre n°1", "Description n°1"));
            MaListeComplexe.Add(new ObjetComplexe("Titre n°2", "Description n°2"));
            MaListeComplexe.Add(new ObjetComplexe("Titre n°3", "Description n°3"));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MonTexte = "Un autre texte !";
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            MaListe.Add("Elément n°" + (MaListe.Count + 1).ToString());
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            MaListe.Remove(TexteSelectionne);
        }

        private void AddComplexButton_Click(object sender, RoutedEventArgs e)
        {
            //MaListeComplexe.Add(new ObjetComplexe("Titre n°" + (MaListeComplexe.Count + 1).ToString(), "Description n°" + (MaListeComplexe.Count + 1).ToString()));
            MaListeComplexe[0].Description = "Une autre description";
        }

        private void DeleteComplexButton_Click(object sender, RoutedEventArgs e)
        {
            MaListeComplexe.Remove(ObjetSelectionne);
        }

    }
}
