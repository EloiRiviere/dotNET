﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class ObjetComplexe : BaseNotifyPropertyChanged
    {
        public string Titre
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public string Description
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public ObjetComplexe(string titre, string description)
        {
            Titre = titre;
            Description = description;
        }

        public override string ToString()
        {
            return Titre + " - " + Description;
        }
    }
}
